{
  "items": [{
    "name": "Mini Arcade Machine",
    "price": "17.89",
    "was-price": "24.99",
    "availability": 1,
    "image": "https://resources3.findmeagift.com/site_media/images/products/286/fun304-mini-arcade-machine-1800x1800.jpg"
  },
  {
    "name": "Stay Cool Ice Towel",
    "price": "7.49",
    "was-price": "9.89",
    "availability": 1,
    "image" : "https://resources3.findmeagift.com/site_media/images/products/286/zdzi150-Stay-Cool-Ice-towel-lifestyle-1-1800x1800.jpg"
  },
  {
    "name": "Sudoku Cube Puzzle",
    "price": "3.09",
    "was-price": "3.99",
    "availability": 1,
    "image" : "https://resources2.findmeagift.com/site_media/images/products/286/PU4600%20Soduko%20Cube-2.jpg"
  },
  {
    "name": "Scratch Map Deluxe Edition",
    "price": "12.99",
    "availability": 1,
    "image" : "https://resources4.findmeagift.com/site_media/images/products/286/luc126_Scratch_Map_Deluxe_Edition_FC_1800.jpg"
  }   
  ]
}